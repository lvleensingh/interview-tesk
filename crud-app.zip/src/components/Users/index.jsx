import React, { useState, useEffect } from 'react'
import './Users.css'
import { apiUrl } from '../../services/apiUrl';
import UpdateUser from '../UpdateUser';
import AddUser from '../AddUser';

const Users = () => {
    const [users, setUsers] = useState([]);
    const [selectedUser, setSelectedUser] = useState(null);
    const [isEdit, setIsEdit] = useState(false)
    const [isAdd, setIsAdd] = useState(false)

    // Fetch users on component mount
    useEffect(() => {
        fetchUsers();
    }, []);

    const handleAddUser = () => {
        setIsAdd(true)
    }
    const handleEditUser = (user) => {
        setSelectedUser(user)
        setIsEdit(true)
    }

    // Fetch users from API
    const fetchUsers = async () => {
        try {
            const response = await fetch(`${apiUrl}?page=2`);
            const data = await response.json();
            setUsers(data.data);
            console.log(data)
        } catch (error) {
            console.error('Error fetching users:', error);
        }
    };

    // Create a new user
    const addUser = async (userData) => {
        try {
            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(userData),
            });
            const data = await response.json();
            setUsers([...users, data]);
        } catch (error) {
            console.error('Error adding user:', error);
        }
    };

    // Update an existing user
    const updateUser = async (userData) => {
        try {
            const response = await fetch(`${apiUrl}/${userData.id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(userData),
            });
            const updatedUser = await response.json();
            const updatedUsers = users.map((user) =>
                user.id === updatedUser.id ? updatedUser : user
            );
            setUsers(updatedUsers);
            setSelectedUser(null);
        } catch (error) {
            console.error('Error updating user:', error);
        }
    };

    // Delete a user
    const deleteUser = async (userId) => {

        try {
            await fetch(`${apiUrl}/${userId}`, {
                method: 'DELETE',
            });
            const updatedUsers = users.filter((user) => user.id !== userId);
            setUsers(updatedUsers);
        } catch (error) {
            console.error('Error deleting user:', error);
        }
    };
    return (
        <div class="container">
            <div className='p-3'>
                <h1 className='text-center'>User management app</h1>
            </div>
            {isAdd &&
                <AddUser addUser={addUser} initialData={{ id: '', email: '', first_name: '', last_name: '' }} setIsAdd={setIsAdd} />
            }
            {isEdit &&
                <UpdateUser updateUser={updateUser} initialData={selectedUser} setIsEdit={setIsEdit} />
            }
            <div className='mt-5 user-table'>
                <button class="btn btn-success btn-sm my-3" type="button" onClick={() => handleAddUser()}>Add User</button>
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">Id</th>
                            <th scope="col">Name</th>
                            <th scope="col">email</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {users?.map((user) => (

                            <tr>
                                <th scope="row">{user.id}</th>
                                <td>{user.first_name}</td>
                                <td>{user.email}</td>
                                <td>
                                    <div class="d-grid gap-2 d-md-flex">
                                        <button class="btn btn-primary btn-sm me-md-2" type="button" onClick={() => handleEditUser(user)}>Edit</button>
                                        <button class="btn btn-danger btn-sm" type="button" onClick={() => deleteUser(user.id)}>Delete</button>
                                    </div>
                                </td>
                            </tr>
                        ))}



                    </tbody>
                </table>
            </div>
        </div>
    )
}

export default Users