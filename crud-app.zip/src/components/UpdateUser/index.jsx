import React, { useState } from 'react';

const UpdateUser = ({ initialData, updateUser, setIsEdit }) => {
    const [formData, setFormData] = useState(initialData);

    const handleInputChange = (event) => {
        const { name, value } = event.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        if (formData.email == '' && formData.first_name == '' && formData.last_name == '') {
            alert('please fill user details')
            return;
        }
        updateUser(formData);
        setIsEdit(false)
    };
    const handleCloseUser = () => {
        setIsEdit(false)
    }

    return (
        <div className='user-box'>
            <h2>Edit User</h2>
            <form onSubmit={handleSubmit}>
                <div className='input-box'>
                    <input type="text" name="email" value={formData?.email} onChange={handleInputChange} />
                    <label>
                        Email:
                    </label>
                </div>
                <div className='input-box'>
                    <input type="text" name="dob" value={formData?.first_name} onChange={handleInputChange} />
                    <label>
                        First Name:
                    </label>
                </div>
                <div className='input-box'>
                    <input type="text" name="address" value={formData?.last_name} onChange={handleInputChange} />
                    <label>
                        Last Name:
                    </label>
                </div>
                <div className='input-box'>

                    <button type="button" className='btn btn-danger me-2' onClick={() => handleCloseUser()}>Close</button>
                    <button type="submit" className='btn btn-primary'>Submit</button>
                </div>
            </form>
        </div>
    );
};

export default UpdateUser;